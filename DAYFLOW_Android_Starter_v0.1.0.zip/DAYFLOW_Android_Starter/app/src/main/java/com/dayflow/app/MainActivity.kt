package com.dayflow.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val ink = Color.rgb(54, 48, 42)
    private val paper = Color.rgb(247, 244, 239)
    private val accent = Color.rgb(140, 115, 91)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(paper)
            setPadding(20, 24, 20, 16)
        }
        val title = TextView(this).apply {
            text = "DAYFLOW"
            textSize = 30f
            setTextColor(ink)
            typeface = android.graphics.Typeface.create("sans-serif-medium", 0)
        }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "Your Life, In One Place."
            textSize = 14f
            setTextColor(accent)
            setPadding(0, 4, 0, 20)
        })
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        listOf("홈", "달력", "메모", "음악", "MY").forEach { label ->
            val b = Button(this).apply {
                text = label
                isAllCaps = false
                setTextColor(ink)
                setOnClickListener { showPage(label) }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
        showPage("홈")
    }

    private fun showPage(page: String) {
        content.removeAllViews()
        val heading = TextView(this).apply {
            text = page
            textSize = 23f
            setTextColor(ink)
            setPadding(0, 18, 0, 14)
        }
        content.addView(heading)
        when (page) {
            "홈" -> {
                addLine("오늘의 기록과 일정을 한곳에서 관리하세요.")
                addLine("DAYFLOW 프로토타입 0.1.0")
            }
            "달력" -> {
                addLine("일정 관리")
                addAction("일정 추가") {
                    val input = EditText(this).apply { hint = "일정 내용을 입력하세요" }
                    AlertDialog.Builder(this).setTitle("새 일정").setView(input)
                        .setPositiveButton("추가") { _, _ ->
                            if (input.text.isNotBlank()) addLine("• ${input.text}")
                        }.setNegativeButton("취소", null).show()
                }
            }
            "메모" -> {
                addLine("간단한 메모")
                addAction("메모 작성") {
                    val input = EditText(this).apply {
                        hint = "메모를 입력하세요"
                        minLines = 3
                        gravity = Gravity.TOP
                    }
                    AlertDialog.Builder(this).setTitle("새 메모").setView(input)
                        .setPositiveButton("저장") { _, _ ->
                            if (input.text.isNotBlank()) addLine(input.text.toString())
                        }.setNegativeButton("취소", null).show()
                }
            }
            "음악" -> addLine("음악 서비스 연동은 다음 개발 단계에서 추가합니다.")
            "MY" -> {
                addLine("DAYFLOW 설정")
                addLine("테마 · 백업 · 계정 기능은 개발 예정입니다.")
            }
        }
    }

    private fun addLine(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(ink)
            setPadding(0, 10, 0, 10)
        })
    }

    private fun addAction(label: String, action: () -> Unit) {
        content.addView(Button(this).apply {
            text = label
            isAllCaps = false
            setBackgroundColor(accent)
            setTextColor(Color.WHITE)
            setOnClickListener { action() }
        })
    }
}
