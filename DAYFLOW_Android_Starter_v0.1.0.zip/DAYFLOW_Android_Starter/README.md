# DAYFLOW Android Starter 0.1.0

A minimal native Android Kotlin starter for DAYFLOW.

## Requirements
- Android Studio
- JDK 17
- Android SDK 35

## Build
Open this folder in Android Studio, allow Gradle sync, then select Build > Build Bundle(s) / APK(s) > Build APK(s).

## Current prototype
- Home, Calendar, Memo, Music, and MY tabs
- Basic add-schedule and add-memo dialogs

## Not implemented yet
This is an early UI prototype. Data is currently held only in memory and disappears when the app process ends. Persistent database storage, photo/video attachments, device calendar and contacts sync, notifications, cloud backup, music provider integration, production security/privacy work, and Play Store release preparation remain future work.
